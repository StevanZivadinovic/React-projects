const Create = () => {
  return (
    <div className="create">
      <h2>Add a New Blog</h2>
    </div>
  );
}
 
export default Create;